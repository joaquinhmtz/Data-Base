CREATE VIEW vista_cliente AS
  SELECT
    `cli`.`id_cliente`      AS `id_cliente`,
    `cli`.`nombre`          AS `nombre`,
    `cli`.`edad`            AS `edad`,
    `tel`.`telefono`        AS `telefono`,
    `cli`.`email`           AS `email`,
    `ser`.`servicio`        AS `servicio`,
    `pro`.`nombre_producto` AS `nombre_producto`,
    `cli`.`notificacion`    AS `notificacion`,
    `dat`.`rfc`             AS `rfc`,
    `dat`.`razon_social`    AS `razon_social`,
    `dat`.`direccion`       AS `direccion`
  FROM ((((`proyecto`.`cliente` `cli`
    JOIN `proyecto`.`telefono` `tel` ON ((`cli`.`id_cliente` = `tel`.`id_cliente`))) JOIN `proyecto`.`producto` `pro`
      ON ((`cli`.`productos_id` = `pro`.`id_producto`))) JOIN `proyecto`.`servicio` `ser`
      ON ((`cli`.`servicios_id` = `ser`.`id_servicio`))) JOIN `proyecto`.`datos_factura` `dat`
      ON ((`cli`.`id_cliente` = `dat`.`id_cliente`)));
