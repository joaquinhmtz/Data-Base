CREATE PROCEDURE Registrador(IN id_cliente_aux   INT, IN nombre_aux VARCHAR(30), IN edad_aux INT,
                             IN email_aux        VARCHAR(30), IN servicio_aux INT, IN producto_aux INT,
                             IN notificacion_aux TINYINT(1), IN rfc_aux VARCHAR(13), IN direccion_aux VARCHAR(60),
                             IN telefono_aux     INT)
  BEGIN

      INSERT INTO cliente VALUES (id_cliente_aux,nombre_aux,edad_aux,email_aux,servicio_aux,producto_aux,notificacion_aux);
      INSERT INTO datos_factura VALUES (id_cliente_aux,rfc_aux,nombre_aux,direccion_aux,id_cliente_aux);
      INSERT INTO telefono VALUES (NULL,telefono_aux,id_cliente_aux);

  END;
