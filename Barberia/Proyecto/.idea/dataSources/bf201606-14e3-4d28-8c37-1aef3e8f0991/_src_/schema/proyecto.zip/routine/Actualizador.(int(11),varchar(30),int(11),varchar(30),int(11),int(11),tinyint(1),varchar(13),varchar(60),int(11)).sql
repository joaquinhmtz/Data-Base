CREATE PROCEDURE Actualizador(IN id_cliente_aux   INT, IN nombre_aux VARCHAR(30), IN edad_aux INT,
                              IN email_aux        VARCHAR(30), IN servicio_aux INT, IN producto_aux INT,
                              IN notificacion_aux TINYINT(1), IN rfc_aux VARCHAR(13), IN direccion_aux VARCHAR(60),
                              IN telefono_aux     INT)
  BEGIN

    UPDATE cliente set nombre = nombre_aux, edad = edad_aux, email = email_aux, servicios_id = servicio_aux, productos_id = producto_aux, notificacion = notificacion_aux WHERE id_cliente = id_cliente_aux;
    UPDATE telefono set telefono = telefono_aux WHERE id_telefono = id_cliente_aux;
    UPDATE datos_factura set rfc = rfc_aux, razon_social = nombre_aux, direccion = direccion_aux WHERE id_factura = id_cliente_aux;


  END;
